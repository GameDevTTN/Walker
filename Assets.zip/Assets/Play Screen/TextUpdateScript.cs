﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TextUpdateScript : MonoBehaviour {

    public Slider slider;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void fieldChanged()
    {
        ((Text)gameObject.GetComponent("Text")).text = "" + slider.value;
    }
}
